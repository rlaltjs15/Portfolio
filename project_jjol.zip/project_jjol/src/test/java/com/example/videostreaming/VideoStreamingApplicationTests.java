package com.example.videostreaming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideoStreamingApplicationTests {

    @Test
    void contextLoads() {
    }

}
