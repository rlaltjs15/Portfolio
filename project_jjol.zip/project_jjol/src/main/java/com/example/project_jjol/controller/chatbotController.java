package com.example.project_jjol.controller;

import org.springframework.web.bind.annotation.GetMapping;

public class chatbotController {
 
	@GetMapping("/chatbot")
	public void chatbot() {
		
	}
}
