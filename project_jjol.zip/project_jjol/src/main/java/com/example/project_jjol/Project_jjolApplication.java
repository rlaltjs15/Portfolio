package com.example.project_jjol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project_jjolApplication {
    public static void main(String[] args) {
        SpringApplication.run(Project_jjolApplication.class, args);
    }
}
